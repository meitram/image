$("body").append("<div id='modal'>Some appended text.</div>");
$("body").append("<button class='trigger'>Modal</button>");

$("#modal").iziModal();