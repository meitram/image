  let changeBg = document.getElementById('changeBg');

    changeBg.onclick = function(element) {
    let url = element.target.value;
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.executeScript(
          tabs[0].id,
          {code: 'document.querySelector("div#dashboard").classList.toggle(\'bgImage\');'});
    });
  };